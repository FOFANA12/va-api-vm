<?php

namespace Database\Seeders;

use App\Models\Stakeholder;
use Illuminate\Database\Seeder;

class StakeholderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Stakeholder::factory()->count(5)->create();
    }
}
